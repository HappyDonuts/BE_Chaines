% Parametres de G
Kh = 36;
R = 1;
Telec = 0.002;

% Parametres de F
Si = 0.10416;
Kfar = 1.457;
T3 = 0.0001122;

% Calcul de G et F
G = tf(Kh,[Telec 1]);
F = tf(Si*Kfar,[T3 1]);

% Parametres de C
T1 = Telec;
Ft = 500;
wt = 2*pi*Ft;
T2 = (Kh/R*Si*Kfar)/(sqrt(1+(T3*wt)^2)*wt);

% Calcul de C
C = tf([T1 1],[T2 0]);
bode(C*G*F);
[gm,pm,w,a]=margin(C*G*F);

% Frequence d'echantillonage
Fe = 50*Ft;
Te = 1/Fe;

% Calcul de C bilineaire
Cz = tf([((Te/2)+Telec)/T2 ((Te/2)-Telec)/T2], [1 -1]);
%Cz2 = c2d(C, Te)

sim('simu',0.004);
